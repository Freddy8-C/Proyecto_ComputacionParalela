#ifndef MEDIANBLUR_H
#define MEDIANBLUR_H
#include "opencv2/imgproc.hpp"
#include "opencv2/imgcodecs.hpp"
#include "opencv2/highgui.hpp"
using namespace std;
using namespace cv;

class medianBlur
{
public:
    medianBlur();
    //int functioanmeadi(int MAX_KERNEL_LENGTH,int DELAY_BLUR,Mat src,Mat dst);
};

#endif // MEDIANBLUR_H

#ifndef SECONDMOMENT_H
#define SECONDMOMENT_H


class SecondMoment
{
public:
    SecondMoment();
    void functionSecondMoment();
};

#endif // SECONDMOMENT_H

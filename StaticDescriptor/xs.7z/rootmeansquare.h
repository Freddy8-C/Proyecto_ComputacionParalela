#ifndef ROOTMEANSQUARE_H
#define ROOTMEANSQUARE_H


class RootMeanSquare
{
public:
    RootMeanSquare();
    //float rmsValue(int arr[], int n);
};

#endif // ROOTMEANSQUARE_H

#ifndef RUNPERCENTAGE_H
#define RUNPERCENTAGE_H


class RunPercentage
{
public:
    RunPercentage();
};

#endif // RUNPERCENTAGE_H

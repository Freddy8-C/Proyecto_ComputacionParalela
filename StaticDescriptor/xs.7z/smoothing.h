#ifndef SMOOTHING_H
#define SMOOTHING_H
#include "opencv2/imgproc.hpp"
#include "opencv2/imgcodecs.hpp"
#include "opencv2/highgui.hpp"
using namespace std;
using namespace cv;


class Smoothing
{
public:
    Smoothing();
    int functionSmot(int argc, char ** argv);
    int display_caption();
    int display_dst( int delay );
};

#endif // SMOOTHING_H

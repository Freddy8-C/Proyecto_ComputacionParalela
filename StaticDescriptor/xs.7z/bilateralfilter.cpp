#include "bilateralfilter.h"

bilateralFilter::bilateralFilter()
{

}

/*int functionBilateral(int MAX_KERNEL_LENGTH,int DELAY_BLUR,Mat src,Mat dst){
 * Smoothing *sfn = new Smoothing();
    for ( int i = 1; i < MAX_KERNEL_LENGTH; i = i + 2 )
      {
          bilateralFilter ( src, dst, i, i*2, i/2 );
          if( sfn->display_dst(DELAY_BLUR) != 0 )
          {
              return 0;
          }
      }
}*/

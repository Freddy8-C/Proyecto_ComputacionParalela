#ifndef SKEWNESS_H
#define SKEWNESS_H


class Skewness
{
public:
    Skewness();
    //float mean(float arr[], int n);
    //float standardDeviation(float arr[],int n);
    //float skewness(float arr[], int *n);
};

#endif // SKEWNESS_H

#include "gaussianblur.h"

GaussianBlur::GaussianBlur()
{

}

/*int functionGausian(int MAX_KERNEL_LENGTH,int DELAY_BLUR,Mat src,Mat dst ){
    Smoothing *sfn = new Smoothing();
    for ( int i = 1; i < MAX_KERNEL_LENGTH; i = i + 2 )
       {
           GaussianBlur( src, dst, Size( i, i ), 0, 0 );
           if( sfn->display_dst(DELAY_BLUR) != 0 )
           {
               return 0;
           }
       }
}*/
